# Élections cantonales de Rennes de 2011 - ENSIBS 2020

Cette application web contient les données des élections cantonales de Rennes pour l'année 2011.
Elle a été réalisée dans le cadre d'un projet pour le module de programmation web de première année de Cybersécurité du Logiciel.

## Installation

Dézippez l'archive dans l'emplacement de votre choix.
Ouvrez le ficher index.html dans le navigateur de votre choix.
Baladez-vous!



## Auteurs

Cette application web a été réalisée par BOËDA Malo et SOMMER Clément.
Nous sommes deux élèves issus de la promotion 2019-2022 de l'ENSIBS en Cybersécurité du Logiciel.
